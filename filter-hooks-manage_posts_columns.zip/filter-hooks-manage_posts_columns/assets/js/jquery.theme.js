(function( $ ){

  $('.single-portfolio a.button').attr( 'target', '_blank' );

})( jQuery );
