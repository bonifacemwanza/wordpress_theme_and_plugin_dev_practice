(function(){
  var projectButton = document.querySelector( '.single-portfolio a.button' );
  projectButton.target = '_blank';
})();
